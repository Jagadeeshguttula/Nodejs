import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { UpdateService } from '../services/update.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
 catdata:object;
 subcatdata:object;
 subsubcatdata:object
 //above three are dropdown data setter browser
 subcat:object;
 subsubcat:object;
 drpcat:object;
 drpsubcat:object;
 drpsubsubcat:object;
 txtname:string;
 txtcolor:string;
 txtoldprice:string;
 txtnewprice:string;
 txtdescription:string;
  constructor(private comser:CommonService,private updateser:UpdateService) { }
  funsaveproducts(){
    var obj={pname:this.txtname,cat:this.drpcat,subcat:this.drpsubcat,subsubcat:this.drpsubsubcat}
    this.updateser.serProductInsert(obj).subscribe((dt:any)=>{
    alert(dt.result)
    var fileobj=<HTMLFormElement>document.getElementById("frm1")
        fileobj.submit()
    })
  }
//catdata get
//  CatGet(){
//    this.catdata = this.comser.serGetCategoryGetter().subscribe(dt=>{
//       this.catdata = dt;
//       if(dt == null){
//          this.comser.serCatSetter().subscribe(dt=>{
//              this.catdata = dt;
//          })
//       }
//    })
//  }
  ngOnInit() {
  }

}
