rt=exp.Router()
rt.post("/insproducts",(req,res)=>{
    objid={

        cat_id:oid(req.body.cat_id),
        subcat_id:oid(req.body.subcat_id),
        subsubcat_id:oid(req.body.subsubcat_id),
        // pname:req.body.pname,
        // color:req.body.color,
        // oldprice:req.body.oldprice,
        // newprice:req.body.newprice,
        // description:req.body.description,
        // rating:req.body.rating,
        // offer:req.body.offer,
        // producttype:req.body.producttype,
        // size:req.body.size
    }
     conn.tbl_products.save(objid,()=>{
         res.send({result:"inserted produstsdata"})
     })
    // conn.tbl_products.save(req.body)
    // console.log(req.body)
    //     res.send({result:"Inserted"})
    })
rt.post("/moveimages",(req,res)=>{
    arr=[]
        for(i=0;i<req.files.file1.length;i++)
        {
            cont=req.files.file1[i]
            dt=new Date();
            fname=dt.getTime()+req.files.file1[i].name
    
            cont.mv("./src/assets/images/"+fname)
            arr.push(fname)
        }
        conn.tbl_products.find().sort({_id:-1}).limit(1,(err,result)=>{
            rowid=result[0]._id
            conn.tbl_products.update({_id:oid(rowid)},{$set:{images:arr}})
        })
        res.send({result:"Image Updated"})
         console.log(req.body)
        console.log(arr)
    })




    rt.get("/getproduct",(req,res)=>{
        conn.tbl_products.find((err,result)=>{
        if(err)
        res.send(err)
        else
        res.send(result)
        })
        })
module.exports=rt