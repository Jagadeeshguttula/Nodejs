rt = exp.Router()
rt.get("/getsubcatdata", (req, res) => {
  conn.tbl_subcategory.find((err, result) => {
    if (err)
      res.send(err)
    else
      res.send(result)   
      // console.log(result)
             
  })

})
rt.post("/inssubcatdata", (req, res) => {
  conn.tbl_subcategory.save(req.body, (err,result) => {
    res.send({ resp: "Inserted Subcatdata"})
    // console.log(result)
  })
})
module.exports = rt
