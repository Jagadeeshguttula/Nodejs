import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-subsubcategory',
  templateUrl: './subsubcategory.component.html',
  styleUrls: ['./subsubcategory.component.css']
})
export class SubsubcategoryComponent implements OnInit {
  subsubtbl:object;searchsubsubcat;subasds:boolean=true;tmp=0;
subsubcatname;drpsubchnge;subcatname;catname;
txtsubsubcat;
txtsubcat;
txtcatname;myform:FormGroup;
  constructor(private comser:CommonService) { 
    // this.subsubtbl=[
    //   {subsubcatid:1,subsubcatname:"Lg", subcatname:"Tv", catname:"Electronics" ,active:1},
   
    // ]

    this.myform=new FormGroup({
      txtsubsubcat:new FormControl("",[Validators.required]),
      txtsubcat:new FormControl("", [Validators.required]),
      txtcatname:new FormControl("",[Validators.required])
    })

    this.funsubsubget()
  }

  funsubsubget(){
    this.comser.serSubSubCatGetter().subscribe((dt:any)=>{
       this.subsubtbl=dt
      if(this.subsubtbl==null){
      this.comser.serSubSubCatSetter().subscribe((dt:any)=>{
        this.subsubtbl=dt
      })
      }
    
    })
  }

  funedit(obj){
    this.tmp=obj._id;
    this.subsubcatname=obj.subsubcatname;
    this.subcatname=obj.subcatname;
    this.catname=obj.catname;
    this.drpsubchnge=obj.active
  }
  funsavesubsubcat(){
    var objdata={subsubcatname:this.txtsubsubcat,subcatname:this.txtsubcat,catname:this.txtcatname,active:1}
    this.comser.serInsSubSubcatdata(objdata).subscribe((dt:any)=>{
      //alert(dt.resp)
      if(dt.resp==0){
        alert("SubSub Cat Data Not Get")
      }
      this.comser.serSubSubCatSetter().subscribe(dt=>{      
        this.funsubsubget()
      this.txtsubsubcat=""
      this.txtsubcat=""
      this.txtcatname=""
      this.comser.modalEmitter.emit({resp: "SubSubCategory Loaded"})
    })

    })
  }

  ngOnInit() {
  }


}
