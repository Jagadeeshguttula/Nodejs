import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usercommon',
  templateUrl: './usercommon.component.html',
  styleUrls: ['./usercommon.component.css']
})
export class UsercommonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
