import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { UserService } from '../services/user.service';
declare var $:any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
catdata;
subcatdata;
subsubcatdata;
  constructor(private comser:CommonService,private userser:UserService) {
    this.comser.serGetCategoryGetter().subscribe(dt=>{
      if(dt==null)
        this.comser.serCatSetter().subscribe(dt=>{
          this.catdata=dt
        })
        // checking purpose else block
        //else
        //this.catdata=dt
      
    })
    this.comser.serSubCatGetter().subscribe(dt=>{
      if(dt==null)
      this.comser.serSubcatSetter().subscribe(dt=>{
        this.subcatdata=dt
      })
      // checking purpose else block
        //else
        //this.subdata=dt
    })
    this.comser.serSubSubCatGetter().subscribe(dt=>{
      if(dt==null)
      this.comser.serSubSubCatSetter().subscribe(dt=>{
        this.subsubcatdata=dt
      })
    })
   }
   funlogindiv(){
    $("#main").css("display","block")
    $("#logindiv").toggle("fade",1000)
    $("#logindiv").modal("display","none")  
    
  }
  fun2regform(){
    $("#regform").toggle("fade",1000)
    $("#regform").modal("show")
   
   }
   
   funregform(){
     if(localStorage.getItem("form"))
     {
       alert("Created")
     }
     else
     {
       this.fun2regform()
     }
    
   }
  ngOnInit() {
  }

}
