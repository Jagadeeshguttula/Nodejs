import { RouterModule, Routes } from '@angular/router';
import { NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsercommonComponent } from './usercommon/usercommon.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { ProductsComponent } from './products/products.component';
import {MatButtonModule, MatInputModule} from "@angular/material";
import { ProductinfoComponent } from './productinfo/productinfo.component';
import { AddtocartComponent } from './addtocart/addtocart.component';
import { UserComponent } from './user/user.component';
import { CarouselComponent } from './carousel/carousel.component';
import { UpcomingsliderComponent } from './upcomingslider/upcomingslider.component'
const routes:Routes=[
  {path:"",component:UsercommonComponent,children:[
    {path:"",component:UserComponent},
    {path:"",component:UserComponent},
    {path:"products",component:ProductsComponent},
    {path:"productinfo",component:ProductinfoComponent},
    {path:"addtocart",component:AddtocartComponent}

  ]},
]


@NgModule({
  declarations: [UsercommonComponent, HeaderComponent, FooterComponent, ProductsComponent, ProductinfoComponent, AddtocartComponent, UserComponent, CarouselComponent, UpcomingsliderComponent],
  imports: [
    MatInputModule,MatButtonModule,CommonModule,RouterModule.forChild(routes)
  ],
  providers:[HeaderComponent]
})

export class UserModule { }
