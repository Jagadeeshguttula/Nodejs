import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addtocart',
  templateUrl: './addtocart.component.html',
  styleUrls: ['./addtocart.component.css']
})
export class AddtocartComponent implements OnInit {
  cart_data:any=[];
  constructor() { 
   this.fungetlocaldata()
  }
  fungetlocaldata(){
    this.cart_data=[]
    var dt=localStorage.getItem("prod").split("&&")
    for(var i=0;i<dt.length;i++)
    this.cart_data.push(JSON.parse(dt[i]))
  }
  //delete addtocart products in addcart page ..start
  funDel(pn){
  //alert(pn)
  var rv=confirm("You want to delete?")
  if(rv==true)
  {
  var nstr=""
  for(var i=0;i<this.cart_data.length;i++)
  {
    if(this.cart_data[i].pname!=pn)
    {
    //  alert(this.cart_data[i].pname)
    nstr+=JSON.stringify(this.cart_data[i])
    nstr+="&&"
    }
   
  }
  alert(nstr)
  nstr=nstr.substr(0,nstr.length-2)
  localStorage.setItem("prod",nstr)
  this.fungetlocaldata()
}
else
{
  
}
}
  ngOnInit() {
  }

}