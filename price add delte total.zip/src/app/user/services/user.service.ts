import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
    constructor(private ht:HttpClient) {}
      serGetProductsOfsubsubid(ob){
    return this.ht.post("http://localhost:1234/productspath/getproductsbasedonsubsubcatid",ob)
   }
   setGetProductsBasedOnId(ob){
     return this.ht.post("http://localhost:1234/productspath/getproductsbasedonId",ob)
   }
   serGetUpcomingProducts(){
     return this.ht.get("http://localhost:1234/productspath/getupcomingproducts")
   }
}
