export class Settings {
    constructor(){
this.serUrl="http://localhost:1234"
    }
    serUrl:string
}
